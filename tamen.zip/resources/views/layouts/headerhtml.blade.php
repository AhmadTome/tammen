<html>
<head>
<meta charset="utf-8">
    <title>first page</title>

</head>
<body>
@yield('content')
</body>

</html>
