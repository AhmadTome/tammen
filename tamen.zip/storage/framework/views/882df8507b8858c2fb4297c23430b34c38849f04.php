<table class="table table-bordered">
                <tr>
                    <th width="30%">
                        <?php echo e(_t('production_date',$l)); ?>

                    </th>
                    <td colspan="2">
                        <?php echo e(date('Y-m-d')); ?>

                    </td>
                </tr>
                <tr>
                    <th width="30%">
                        <?php echo e(_t('file_num',$l)); ?>

                    </th>
                    <td width="20%">
                        <?php echo e(explode('-',$car['file_num'])[1]); ?>

                    </td>
                    <td>
                        <?php echo e(explode('-',$car['file_num'])[0]); ?>

                    </td>
                </tr>
            </table>