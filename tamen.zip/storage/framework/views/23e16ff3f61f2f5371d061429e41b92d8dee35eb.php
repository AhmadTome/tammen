<div class="row border-2 padding">
        <table class="table table-bordered black-header">
            <thead>
                <tr>
                    <th>
                        <?php echo e(_t('car_num',$l)); ?>

                    </th>
                    <th>
                        <?php echo e(_t('file_num',$l)); ?>

                    </th>
                    <th>
                        <?php echo e(_t('car_use',$l)); ?>

                    </th>
                    <th>
                        <?php echo e(_t('model_type',$l)); ?>

                        
                    </th>
                    <th>
                        <?php echo e(_t('production_year',$l)); ?>

                    </th>
                    <th>
                        <?php echo e(_t('body_num',$l)); ?>

                    </th>
                    <th>
                        <?php echo e(_t('production_date',$l)); ?>

                    </th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>
                        <?php echo e($car['ve_num']); ?>

                    </td>
                    <td>
                        <?php echo e($car['file_num']); ?>

                    </td>
                    <td>
                        <?php echo e($car['ve_used']); ?>

                    </td>
                    <td>
                        <?php echo e($car['ve_version']); ?>

                    </td>
                    <td>
                        <?php echo e($car['ve_produce_year']); ?>

                    </td>
                    <td>
                        <?php echo e($car['ve_body_num']); ?>

                    </td>
                    <td>
                        <?php echo e(date('Y-m-d')); ?>

                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    <br>