<?php $__env->startSection('title','أعمال مركبة'); ?>

<?php $__env->startSection('content'); ?>

    <div class="text-center border-1 gray-back">
        <h3>
            <?php echo e(_t('tech_damage_table',$l)); ?>

        </h3>
    </div>
    <Br>
    <?php echo $__env->make('report.parts.carInfoHeader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <br>
    <div class='row border-1' style="height:100px;">

    </div>
    <hr>
    <div class="col-xs-3 col-xs-offset-9">
        <table class="table table-bordered">
            <tr>
                <th width="30%">
                    <?php echo e(_t('car_price',$l)); ?>

                </th>
                <td>
                    
                </td>
            </tr>
        </table>
    </div>
    <div class="clearfix"></div>
    <br>
    <div class='col-xs-6 col-xs-offset-6'>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>
                        <?php echo e(_t('part',$l)); ?>

                    </th>
                    <th>
                        <?php echo e(_t('maintenece',$l)); ?>

                    </th>
                    <th>
                        <?php echo e(_t('part_count',$l)); ?>

                    </th>
                    <th>
                        <?php echo e(_t('work_ratio',$l)); ?>

                    </th>
                    <th>
                        <?php echo e(_t('down_ratio')); ?>

                    </th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>
                        
                    </td>
                    <td>
                        
                    </td>
                    <td>
                        
                    </td>
                    <td>
                        
                    </td>
                    <td>
                        
                    </td>
                </tr>
                <tr>
                    <th colspan="3">
                        <?php echo e(_t('total_down_ratio',$l)); ?>

                    </th>
                    <td>
                    </td>
                </tr>
                <tr>
                    <th colspan="3">
                        <?php echo e(_t("direct_damage",$l)); ?>

                    </th>
                    <td>
                    
                    </td>
                </tr>
                <tr>
                    <th colspan='3'>
                        <?php echo e(_t('total_drop_value',$l)); ?>

                    </th>
                    <td>
                    
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    <div class="clearfix"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('report.reportLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>