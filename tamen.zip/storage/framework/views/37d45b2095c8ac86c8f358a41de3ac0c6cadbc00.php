<?php $__env->startSection('title','شهادة تثمين'); ?>

<?php $__env->startSection('content'); ?>

    <h3 class="text-center">
        <b>
            <u>
                <?php echo e(_t('bank_stmnt_title',$l)); ?>

            </u>
        </b>
    </h3>
    <div class="row">
        <div class="col-xs-6">
            <table class="table table-bordered">
                <tr>
                    <th width="40%">
                        <?php echo e(_t('production_date',$l)); ?>

                    </th>
                    <td colspan="2">
                        <?php echo e(date('Y-m-d')); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('file_num',$l)); ?>

                    </th>
                    <td width="20%">

                    </td>
                    <td width="40%">
                    
                    </td>
                </tr>
            </table>
        </div>
        <div class="col-xs-6">
            <table class="table table-bordered">
                <tr>
                    <th width="30%">
                        <?php echo e(_t('name',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($person->name); ?>

                    </td>
                </tr>
                <tr>
                    <th width="30%">
                        <?php echo e(_t('address',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($person->address); ?>

                    </td>
                </tr>
            </table>
        </div>
    </div>
    <br>
    <div class='row border-2'>
        <h3 class='text-center margin-0'>
            <?php echo e(_t('file_num',$l)); ?>: <?php echo e($carInfo->file_num); ?>

        </h3>
    </div>
    <br>
    <div class="row">
        <div class="col-xs-6">
            <table class="table table-bordered">
                <tr>
                    <th width="30%">
                        <?php echo e(_t('car_num',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($carInfo->ve_num); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('body_num',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($carInfo->ve_body_num); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('car_model',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($carInfo->ve_version); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('production_year',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($carInfo->ve_produce_year); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('car_use',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($carInfo->ve_used); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('weight',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($carInfo->ve_weight); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('engine_size',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($carInfo->ve_engin_size); ?>

                    </td>
                </tr>
            </table>
        </div>
        <div class="col-xs-6">
            <table class="table table-bordered">
                <tr>
                    <th width="30%">
                        <?php echo e(_t('car_owner_name',$l)); ?>

                    </th>
                    <td>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('car_owner_id',$l)); ?>

                    </th>
                    <td>
                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('walk_power',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($carInfo->ve_power_push); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('car_color',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($carInfo->ve_color); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('gas_type',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($carInfo->ve_gas_type); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('pass_num',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($carInfo->seat_num); ?>

                    </td>
                </tr>
            </table>
        </div>
    </div>
    <br>
    <div class="border-1">
        <h3 class="text-center margin-0">
            <?php echo e(_t('car_exam_result',$l)); ?>

        </h3>
    </div>
    <br>
    <div class="row">
        <div class="col-xs-6">
            <table class="table table-bordered">
                <tr>
                    <th width="30%">
                        <?php echo e(_t('front_face',$l)); ?>

                    </th>
                    <td>
                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('suspen_device',$l)); ?>

                    </th>
                    <td>
                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('engine',$l)); ?>

                    </th>
                    <td>
                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('gear_box',$l)); ?>

                    </th>
                    <td>
                    </td>
                </tr>
                <tr>
                    <th>
                        2
                    </th>
                    <td>
                    </td>
                </tr>
                <tr>
                    <th>
                        4
                    </th>
                    <td>
                        
                    </td>
                </tr>
                <tr>
                    <th>
                        6
                    </th>
                    <td></td>
                </tr>
            </table>
        </div>
        <div class="col-xs-6">
            <table class="table table-bordered">
                <tr>
                    <th width="30%">
                        <?php echo e(_t('front',$l)); ?>

                    </th>
                    <td>
                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('right_side',$l)); ?>

                    </th>
                    <td>
                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('left_side',$l)); ?>

                    </th>
                    <td>
                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('back',$l)); ?>

                    </th>
                    <td>
                    </td>
                </tr>
                <tr>
                    <td>
                        1
                    </td>
                    <td>
                    </td>
                </tr>
                <tr>
                    <th>
                        3
                    </th>
                    <td>
                    </td>
                </tr>
                <tr>
                    <th>
                        5
                    </th>
                    <td></td>
                </tr>
            </table>
        </div>
    </div>
    <div class="border-1">
        <h3 class='text-center margin-0'>
            <?php echo e(_t('car_attachments',$l)); ?>

        </h3>
    </div>
    <br>
    <table class="table table-bordered">
        <tr>
            <td width="20%" style="padding-top: 10px !important;padding-bottom: 10px !important;">
                <?php echo e(_t('guess_val',$l)); ?>

            </td>
            <td>
            
            </td>
        </tr>
        <tr>
            <td style="padding-top: 20px !important;padding-bottom: 20px !important;">
                <?php echo e(_t('notes',$l)); ?>

            </td>
            <td>
            
            </td>
        </tr>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('report.reportLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>