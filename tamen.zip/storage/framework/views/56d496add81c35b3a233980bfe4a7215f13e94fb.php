<?php $__env->startSection('title','Personal File Account'); ?>

<?php $__env->startSection('content'); ?>

    <div class="border-2 padding">
        <table class="table table-bordered">
            <tr>
                <th>
                    <?php echo e(_t('car_num',$l)); ?>

                </th>
                <th>
                    <?php echo e(_t('file_num',$l)); ?>

                </th>
                <th>
                    <?php echo e(_t('car_use',$l)); ?>

                </th>
                <th>
                    <?php echo e(_t('car_model',$l)); ?>

                </th>
                <th>
                    <?php echo e(_t('production_year')); ?>

                </th>
                <th>
                    <?php echo e(_t('body_num',$l)); ?>

                </th>
            </tr>
            <tr>
                <td>
                    <?php echo e($car['ve_num']); ?>

                </td>
                <td>
                    <?php echo e($car['file_num']); ?>

                </td>
                <td>
                    <?php echo e($car['ve_used']); ?>

                </td>
                <td>
                    <?php echo e($car->ve_version); ?>

                </td>
                <td>
                    <?php echo e($car['ve_produce_year']); ?>

                </td>
                <td>
                    <?php echo e($car['ve_body_num']); ?>

                </td>
            </tr>
        </table>
    </div>
    <br>
    <div class="col-xs-6">
        <table class="table table-bordered cols-2">
            <tr>
                <th>
                    <?php echo e(_t('production_date',$l)); ?>

                </th>
                <td>
                    <?php echo e(date('Y-m-d')); ?>

                </td>
            </tr>
            <tr>
                <th>
                    <?php echo e(_t('file_num',$l)); ?>

                </th>
                <td>
                    <?php echo e($car['file_num']); ?>

                </td>
            </tr>
        </table>
    </div>
    <div class="col-xs-6">
        <table class="table table-bordered cols-2">
            <tr>
                <th>
                    <?php echo e(_t('for',$l)); ?>

                </th>
                <td>
                    <?php echo e($est['to']); ?>

                </td>
            </tr>
            <tr>
                <th>
                    <?php echo e(_t('city',$l)); ?>

                </th>
                <td>
                    <?php echo e($est['city']); ?>

                </td>
            </tr>
            <tr>
                <th>
                    <?php echo e(_t('jawwal',$l)); ?>

                </th>
                <td>
                    
                </td>
            </tr>
        </table>
    </div>
    <div class="clearfix"></div>

    <h4 class='text-center'>
        <?php echo e(_t('car_check_msg',$l)); ?>

    </h4>
    <div class="border-2 padding">
        <div class="col-xs-4">
            <?php echo e(_t('claim_num',$l)); ?>: <?php echo e($est['climeNumber']); ?>

        </div>
        <div class='col-xs-4'>
            <?php echo e(_t('file_num',$l)); ?>: <?php echo e($est['fileNumber']); ?>

        </div>
        <div class='col-xs-4'>
            <?php echo e(_t('benif_name',$l)); ?>: <?php echo e($est['person_insurances']); ?>

        </div>
        <div class="clearfix"></div>
    </div>
    <Br>


    <div class="Row">
        <div class="col-xs-6">
            <table class="table table-bordered">
                <tr>
                    <th width="30%">
                        <?php echo e(_t('acc_date',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($est['accidantDate']); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('car_num',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($car['ve_num']); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('car_model',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($car->ve_version); ?>

                    </td>
                </tr>
                <tr>
                    <th width="30%">
                        <?php echo e(_t('production_year',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($car['ve_produce_year']); ?>

                    </td>
                </tr>
            </table>
            <br>
        </div>
        <div class="col-xs-6">
            <table class="table table-bordered">
                <tr>
                    <th width="30%">
                        <?php echo e(_t('name',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($est['persone_name']); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('ins_name',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($est['person_insurances']); ?>

                    </td>
                </tr>
                <tr>
                    <th width="30%">
                        <?php echo e(_t('ins_policy',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($est['Insurance_policy']); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('ins_company',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($est['insurance_company']); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('damage',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($est['DamageType']); ?>

                    </td>
                </tr>
            </table>
            <br>
            <table class="table table-bordered">
                <tr>
                    <th width="30%">
                        <?php echo e(_t('surv_pay',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($est->estimater_cost); ?>

                    </td>
                </tr>
                <tr>
                    <th width='30%'>
                        <?php echo e(_t('travel',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($est['transport']); ?>

                    </td>
                </tr>
                <tr>
                    <th width="30%">
                        <?php echo e(_t('picture',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($est->gelary); ?>

                    </td>
                </tr>
                <tr>
                    <th width="30%">
                        <?php echo e(_t('disk_money',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($est['officeCost']); ?>

                    </td>
                </tr>
                <tr>
                    <th width="30%">
                        <?php echo e(_t('total',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($est->total + $est->estimater_cost); ?>

                    </td>
                </tr>
            </table>
            <br>
        </div>
        <div class="clearfix"></div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('report.reportLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>