<h4 class="gray-back border-1 padding pull-right margin-0">
                <?php echo e(_t('car_guess_notes',$l)); ?>

            </h4>
            <div class="clearfix">
            </div>
            <div class="box"></div>