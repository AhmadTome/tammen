<?php $__env->startSection('title','إدخال قيمة تخمين'); ?>

<?php $__env->startSection('content'); ?>

<div class="panel panel-default">
            <div class="panel-heading text-center PanelHeadingCss">ادخال قيمة التخمين</div>
            <div class="panel-body PanelBodyCss">

                <div class="container " style="max-width: 1000px ;margin-bottom: -15px">
                    <form class="form-horizontal" method="post" action="storeEstimatevalue">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <div class="col-sm-2"></div>
                            <div class="col-sm-9">
                                <input type="name" class="form-control PanelBodyCssInput" name="textNum" id="textNum" placeholder="ادخل رقم النص" required>
                            </div>
                            <label class="control-label col-sm-1" for="textNum">: الرقم</label>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-2"></div>
                            <div class="col-sm-9">
                                <input type="address" class="form-control PanelBodyCssInput" name="textName" id="textName" placeholder="ادخل نص المركبة" required>
                            </div>
                            <label class="control-label col-sm-1" for="textName">: النص</label>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-2"></div>
                            <div class="col-sm-3">
                                <input type="submit" class="btn btn-success" id="submit" value="إدخال">
                            </div>
                            <label class="control-label col-sm-7"></label>
                        </div>

                        <table class="table" dir="rtl" border="0" id="mytable">
                            <tbody style="text-align: center">

                            <td><label>الرقم</label></td>
                            <td><label>قيمة التخمين</label></td>
                            <td><label>تعديل</label></td>
                            <td><label>حذف</label></td>

                            </tbody>
                            <?php $__currentLoopData = $estimatevalue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td ><label><?php echo e($item->estim_num); ?></label></td>
                                    <td><label><?php echo e($item->estim_name); ?></label></td>

                                    <td style="text-align: center"><input class="edit-modal btn btn-info"  data-id="<?php echo e($item->estim_num); ?>" data-name="<?php echo e($item->estim_name); ?>"
                                                                          value="تعديل"></td>

                                    <td style="text-align: center"><input class="delete-modal btn btn-danger"
                                                                          data-id="<?php echo e($item->estim_num); ?>" data-name="<?php echo e($item->estim_name); ?>"
                                                                          value="حذف"
                                        ></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>

                        <!-- Start Model -->

                        <div id="myModal" class="modal fade" role="dialog">
                            <div class="modal-dialog">
                                <!-- Modal content-->
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        <h4 class="modal-title"></h4>
                                    </div>
                                    <div class="modal-body" >

                                        <form class="form-horizontal" role="form" >
                                            <div class="EditContent">

                                                <div class="form-group" dir="rtl">
                                                    <label class="control-label col-sm-2 pull-right" >الرقم :</label>
                                                    <div class="col-sm-10 pull-right">
                                                        <input type="text" class="form-control" id="insNumber" >
                                                    </div>
                                                </div>
                                                <div class="form-group" dir="rtl">
                                                    <label class="control-label col-sm-2 pull-right"  >قيمة التخمين :</label>
                                                    <div class="col-sm-10 pull-right">
                                                        <input type="text" class="form-control" id="insName">
                                                    </div>
                                                </div>


                                            </div>
                                        </form>



                                        <div class="deleteContent" dir="rtl">
                                            هل أنت متأكد من أنك تريد حذف  <span class="dname"></span> ?
                                            <span class="hidden did"></span>
                                        </div>


                                        <div class="modal-footer">
                                            <button type="button" class="btn actionBtn" data-dismiss="modal">
                                                <span id="footer_action_button" > </span>
                                            </button>
                                            <button type="button" class="btn btn-warning" data-dismiss="modal">
                                                <span></span> Close
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- End Model -->


                    </form>
                </div>


            </div>
        </div>

        <script>
    var lastid_delete;
    var lastname_delete;

    var lastcompanynumnum;
    var lastcompanyname;
    var num_update;
    var companyname_update;


    var deleterow;
    var updaterow;
    $(document).ready(function() {
        $(document).on('click', '.edit-modal', function() {
            $('#footer_action_button').text("Update");
            // $('#footer_action_button').addClass('glyphicon-check');
            //$('#footer_action_button').removeClass('glyphicon-trash');
            $('.actionBtn').addClass('btn-success');
            $('.actionBtn').removeClass('btn-danger');
            $('.actionBtn').addClass('edit');
            $('.modal-title').text('Edit');
            $('.deleteContent').hide();
            $('.EditContent').show();
            $('#insNumber').val($(this).data('id'));
            $('#insName').val($(this).data('name'));

            lastcompanynumnum=$(this).data('id');
            lastcompanyname=$(this).data('name');

            updaterow=$(this).parent().parent();


            $('#myModal').modal('show');
        });


        $(document).on('click', '.delete-modal', function() {
            lastid_delete =$(this).data('id');
            lastname_delete=$(this).data('name');
            deleterow=$(this).parent().parent();
            $('#footer_action_button').text(" Delete");
            // $('#footer_action_button').removeClass('glyphicon-check');
            //$('#footer_action_button').addClass('glyphicon-trash');
            $('.actionBtn').removeClass('btn-success');
            $('.actionBtn').addClass('btn-danger');
            $('.actionBtn').addClass('delete');
            $('.modal-title').text('Delete');
            $('.EditContent').hide();
            $('.did').text($(this).data('id'));
            $('.deleteContent').show();
            $('.dname').html($(this).data('name'));
            $('#myModal').modal('show');
        });

        $('.modal-footer').on('click', '.delete', function() {

            $.ajax({
                type: 'get',
                url: '<?php echo URL::to('deleteestimatevalue'); ?>',
                data: {
                    'num':lastid_delete,
                    'name':lastname_delete
                },
                success: function(data) {
                    //$('.item' + $('.did').text()).remove();
                    console.log(data);
                    deleterow.remove();
                },
                error:function (data) {
                    console.log('error')
                }

            });
        });

        $('.modal-footer').on('click', '.edit', function() {
            num_update=$('#insNumber').val();
            companyname_update=$('#insName').val();


            $.ajax({
                type: 'get',
                url: '<?php echo URL::to('updateestimatevalue'); ?>',
                data: {
                    'num':num_update,
                    'name':companyname_update,

                    'lastnum':lastcompanynumnum,
                    'lastname':lastcompanyname
                },
                success: function(data) {
                    //$('.item' + $('.did').text()).remove();
                    console.log(data)

                    location.reload();
                },
                error:function (data) {
                    console.log('error')
                }

            });




        });



    });








</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>