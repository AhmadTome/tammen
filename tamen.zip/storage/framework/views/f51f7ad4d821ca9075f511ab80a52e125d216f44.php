<?php $__env->startSection('title','حساب ثمن المركبة'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('report.parts.carInfoHeader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class='col-xs-4 col-xs-offset-1'>
            <table class="table table-bordered">
                <tr>
                    <th width="30%">
                        <?php echo e(_t('production_date',$l)); ?>

                    </th>
                    <td colspan="2">
                        <?php echo e(date('Y-m-d')); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('file_num',$l)); ?>

                    </th>
                    <td width="20%">
                        <?php echo e(explode('-',$car['file_num'])[1]); ?>

                    </td>
                    <td>
                        <?php echo e(explode('-',$car['file_num'])[0]); ?>

                    </td>
                </tr>
            </table>
        </div>
    </div>
    <br>
    <table class="table table-bordered">
        <tr>
            <th class="gray-back" colspan="5">
                <?php echo e(_t('car_price_calculate',$l)); ?>

            </th>
        </tr>
        <tr>
            <th class="gray-back">
                <?php echo e(_t('repair_calc',$l)); ?>

            </th>
            <th class="gray-back">
                <?php echo e(_t('body_part_calc',$l)); ?>

            </th>
            <th class="gray-back">
                <?php echo e(_t('mech_part_calc',$l)); ?>

            </th>
            <th class="gray-back">
                <?php echo e(_t('down_calc',$l)); ?>

            </th>
            <th class="gray-back">
                <?php echo e(_t('car_price',$l)); ?>

            </th>
        </tr>
        <tr>
        <td>
            <?php echo e($car->total_maintenance); ?>

        </td>
        <td>
            <?php echo e($car->total_body_work); ?>

        </td>
        <td>
            <?php echo e($car->total_mechanic); ?>

        </td>
        <td>
            <?php echo e((($car->total_drop / 100) * $car->cost->finalcost)); ?>

        </td>
        <td>
            <?php echo e($car->cost->finalcost); ?>

        </td>
        </tr>
    </table>
    <br>
    <div class="row">
        <div class="col-xs-8 col-xs-offset-4">
            <table class="table table-bordered">
                <tr class="gray-back">
                    <th width="50%" colspan="2">
                        <?php echo e(_t('total_inc_down',$l)); ?>

                    </th>
                    <th width="50%"> 
                        <?php echo e(_t('direct_damage_total',$l)); ?>

                    </th>
                </tr>
                <tr>
                    <td width="50%" colspan="2">
                        <?php echo e($car->total_maintenance + $car->total_body_work + $car->total_mechanic + (($car->total_drop / 100) * $car->cost->finalcost)); ?>

                    </td>
                    <td>
                        <?php echo e($car->total_maintenance + $car->total_body_work + $car->total_mechanic); ?>

                    </td>
                </tr>
                <tr>
                    <th class="gray-back">
                        <?php echo e(_t('damage_rate',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($est->DamagePercantige); ?>

                    </td>
                </tr>
            </table>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-xs-9">
            <h4 class="gray-back border-1 padding pull-right margin-0">
                <?php echo e(_t('car_guess_notes',$l)); ?>

            </h4>
            <div class="clearfix">
            </div>
            <div class="box"></div>
        </div>
        <div class="col-xs-3">
            <h4 class="gray-back border-1 padding pull-right margin-0">
                <?php echo e(_t('attachments',$l)); ?>

            </h4>
            <div class="clearfix">
            </div>
            <div class="box"></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('report.reportLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>