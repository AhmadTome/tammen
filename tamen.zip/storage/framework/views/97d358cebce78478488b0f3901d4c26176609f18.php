<?php $__env->startSection('title','صور الحادث'); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .margin-bottom{
            margin-bottom: 10px;
        }
        @page  {
            size : landscape;
        }
    </style>
    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-xs-4 margin-bottom">
            <img src="<?php echo e($img->path); ?>" width="100%" height="100%">
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="clearfix"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('report.reportLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>