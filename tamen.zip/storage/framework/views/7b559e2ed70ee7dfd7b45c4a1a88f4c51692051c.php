<?php $__env->startSection('title','print report'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('report.parts.carInfoHeader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="text-center gray-back padding">
            <?php echo e(_t('car_details',$l)); ?>

        </div>
        <br>
        <div class="col-xs-5">
            <?php echo $__env->make('report.parts.fileInfo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="clearfix"></div>
        <br>


        <div class="col-xs-6">
            <table class="table table-bordered cols-2">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(_t('acc_date',$l)); ?>

                        </th>
                        <td>
                            <?php echo e($est['accidantDate']); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(_t('exam_date',$l)); ?>

                        </th>
                        <td>
                            <?php echo e($est['checkDate']); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(_t('car_num',$l)); ?>

                        </th>
                        <td>
                            <?php echo e($car['ve_num']); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(_t('car_model',$l)); ?>

                        </th>
                        <td>
                            <?php echo e($car['ve_version']); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(_t('car_use',$l)); ?>

                        </th>
                        <td>
                            <?php echo e($car['ve_used']); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(_t('meter',$l)); ?>

                        </th>
                        <td>
                            <?php echo e($car['ve_speedometer']); ?>

                        </td>
                    </tr>
                </tbody>
            </table>
            </div>
            <div class="col-xs-6">
            <table class="table table-bordered cols-2">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(_t('name',$l)); ?>

                        </th>
                        <td>
                            <?php echo e($est['persone_name']); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(_t('ins_name',$l)); ?>

                        </th>
                        <td>
                            <?php echo e($est['person_insurances']); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(_t('ins_policy',$l)); ?>

                        </th>
                        <td>
                            <?php echo e($car['ve_insurence_num']); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(_t('exam_place',$l)); ?>

                        </th>
                        <td>
                            <?php echo e($est['Garage']); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(_t('car_model_num',$l)); ?>

                        </th>
                        <td>
                            <?php echo e($car['ve_version_num']); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(_t('damage',$l)); ?>

                        </th>
                        <td>
                            <?php echo e($est['DamageType']); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(_t('body_num',$l)); ?>

                        </th>
                        <td>
                            <?php echo e($car['ve_body_num']); ?>

                        </td>
                    </tr>
                </tbody>
            </table>
            </div>

            <div>
                <table class="table table-bordered">
                    <tr>
                        <th colspan="4" class="gray-back">
                            <?php echo e(_t('car_desc_add',$l)); ?>

                        </th>
                    </tr>
                    <?php
                        $atts = preg_split ('/[\s*,\s*]*,+[\s*,\s*]*/',$car['attachments']);
                    ?>
                    <?php for($i = 0; $i < count($atts);$i++): ?>
                        <tr>
                            <th width="10%" class="gray-back">
                                <?php echo e($i + 1); ?>

                            </th>
                            <td width="40%">
                                <?php echo e($atts[$i]); ?>

                            </td>
                            <?php $i++; ?>
                            <?php if($i < count($atts)): ?>
                                <th width="10%" class="gray-back">
                                    <?php echo e($i + 1); ?>

                                </th>
                                <td width="40%">
                                    <?php echo e($atts[$i]); ?>

                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endfor; ?>
                </table>
            </div>

            <br>
            <div>
                <p class="pull-right padding border-1">
                    <?php echo e(_t('damage_desc',$l)); ?>

                </p>
                <div class="clearfix"></div>
                <div class="box">

                </div>
            </div>
        </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("report.reportLayout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>