<div class="footer"> <strong>الأشرف للتخمين</strong>.</div>
