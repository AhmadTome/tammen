<html>
<head>
    <title>تقارير المركبة</title>
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link rel="icon" type="image/ico" href="<?php echo e(asset('img/photo2.png')); ?>">
    <link href="<?php echo e(asset('css/AdminCss/SuperadminStyles.css')); ?>" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
</head>
<body>

<div class="container-fluid">
    <!-- Background pic -->
    <div class="BackImageSuperAd" ></div>
    <!-- End of Background pic -->

    <!--
        <div class="row ">
            <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12 text-right" >
                <a href="" class="btn btn-danger exit" title="Exit"><b>Exit</b></a>
            </div>
        </div>
    -->
    <div class="row headrDiv">
        <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12 " >
            <?php echo $__env->make('logodiv', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;

        </div>
    </div>

    <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12 " >
        <?php echo $__env->make('mainpar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;

    </div>

    <!-- Body -->

    <div class="BodyDiv col-lg-12 col-md-12 col-xs-12 col-sm-12  " >
        <div class="panel panel-default">
            <div class="panel-heading text-center PanelHeadingCss">معلومات المركبة</div>
            <div class="panel-body PanelBodyCss">
                <div>
                    <?php echo $__env->make('report.parts.carFileChooser', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <div class="clearfix"></div>
                <br>
                <div class="form-group">
                    <div class="col-sm-6 col-sm-offset-3">
                        <button class='btn btn-primary btn-block' onclick="goTo('carImages')">
                            معاينة صور الحادث
                        </button>
                    </div>
                </div>
                </div>
            </div>
        </div>

</div>
<!-- end car info -->
    </div>
    <!-- end Body -->
    <!--footer-->
    <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12 " >
        <?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;

    </div>
    <!--/footer-->

    <script>
        function goTo(route){
            var type = $("#filenumber").val();
            if(!type){
                $("#fileError").show();
                $("#fileError").html("قم باختيار ملف");
                return;
            }

            $("#fileError").hide();
            $("#fileError").html("");
            
            window.open("/report/" + route + "/" + type);
            
        }
    $(document).ready(function () {
    });
    </script>   

</div>

</body>
</html>