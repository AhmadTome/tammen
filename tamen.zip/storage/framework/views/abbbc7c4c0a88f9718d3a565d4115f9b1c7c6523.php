<?php $__env->startSection('title','Car Destroy'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-sm-6 col-sm-offset-3 border-1 gray-back text-center">
            <h4><b><?php echo e(_t('car_destroy_title',$l)); ?></b></h4>
        </div>
    </div>
    <br>
    <div class='row'>
        <div class='col-xs-5'>
            <table class="table table-bordered">
                <tr>
                    <th width="30%">
                        <?php echo e(_t('production_date',$l)); ?>

                    </th>
                    <td colspan="2">
                        <?php echo e(date('Y-m-d')); ?>

                    </td>
                </tr>
                <tr>
                    <th width="30%">
                        <?php echo e(_t('file_num',$l)); ?>

                    </th>
                    <td width="20%">
                        <?php echo e(explode('-',$car['file_num'])[1]); ?>

                    </td>
                    <td>
                        <?php echo e(explode('-',$car['file_num'])[0]); ?>

                    </td>
                </tr>
            </table>
        </div>
        <div class="col-xs-4 col-xs-offset-3">
            <table class="table table-bordered">
                <tr>
                    <th width="30%">
                        <?php echo e(_t('for',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($est['to']); ?>

                    </td>
                </tr>
            </table>
        </div>
    </div>
    <br>
    
    <div class="row">
        <div class="col-xs-6">
            <table class="table table-bordered cols-2">
                <tr>
                    <th>
                        <?php echo e(_t('acc_date',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($est['accidantDate']); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('exam_date',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($est['checkDate']); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('car_num',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($car['ve_num']); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('car_model',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($car['ve_version']); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('car_use',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($car['ve_used']); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('meter',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($car->ve_speedometer); ?>

                    </td>
                </tr>
            </table>
        </div>
        <div class="col-xs-6">
            <table class="table table-bordered cols-2">
                <tr>
                    <th>
                        <?php echo e(_t('name',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($est['persone_name']); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('ins_name',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($est['person_insurances']); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('ins_policy',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($est['Insurance_policy']); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('car_model_num',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($car['ve_version_num']); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('damage',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($est['DamageType']); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('body_num',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($car['ve_body_num']); ?>

                    </td>
                </tr>
            </table>
        </div>
    </div>
    <div class="box">

    </div>
    <br>
    <div class="col-xs-8 col-xs-offset-2">
        <table class='table table-bordered'>
            <tr>
                <th class="gray-back">
                    <?php echo e(_t('guesser',$l)); ?>

                </th>
                <th class="gray-back">
                    <?php echo e(_t('neg_num',$l)); ?>

                </th>
                <th class="gray-back">
                    <?php echo e(_t('sig_stamp',$l)); ?>

                </th>
            </tr>
            <tr>
                <td>
                    <?php echo e($est['estimaterName']); ?>

                </td>
                <td>
                </td>
                <td></td>
            </tr>
        </table>
    </div>
    <div class="clearfix"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('report.reportLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>