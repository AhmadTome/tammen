<?php $__env->startSection('title','كشف الزيارات'); ?>

<?php $__env->startSection('content'); ?>

    <div class="text-center">
        <h3>
            <?php echo e(_t('visit_log',$l)); ?>

        </h3>
    </div>
    <div class="row">
        <table class="table table-bordered">
            <tr>
                <th>
                    <?php echo e(_t('car_num',$l)); ?>

                </th>
                <th>
                    <?php echo e(_t('file_num',$l)); ?>

                </th>
                <th>
                    <?php echo e(_t('car_use',$l)); ?>

                </th>
                <th>
                    <?php echo e(_t('body_num',$l)); ?>

                </th>
                <th>
                    <?php echo e(_t('car_model',$l)); ?>

                </th>
                <th>
                    <?php echo e(_t('production_year',$l)); ?>

                </th>
                <th>
                    <?php echo e(_t('car_color',$l)); ?>

                </th>
            </tr>
            <tr>
                <td>
                    <?php echo e($car['ve_num']); ?>

                </td>
                <td>
                    <?php echo e($car['file_num']); ?>

                </td>
                <td>
                    <?php echo e($car['ve_used']); ?>

                </td>
                <td>
                    <?php echo e($car['ve_body_num']); ?>

                </td>
                <td>
                    <?php echo e($car['ve_version']); ?>

                </td>
                <td>
                    <?php echo e($car['ve_produce_year']); ?>

                </td>
                <td>
                    <?php echo e($car['ve_color']); ?>

                </td>
            </tr>
        </table>
    </div>
    <hr>
    <div class="row">
        <table class="table table-bordered">
            <tr>
                <th width="10%" class="gray-back">
                    <?php echo e(_t('day',$l)); ?>

                </th>
                <th width='15%' class="gray-back">
                    <?php echo e(_t('visit_date',$l)); ?>

                </th>
                <th width="" class="gray-back">
                    <?php echo e(_t('car_work',$l)); ?>

                </th>
                <th class="gray-back">
                    <?php echo e(_t('notes',$l)); ?>

                </th>
            </tr>
            <?php $__currentLoopData = $visits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($v['vis_day']); ?>

                    </td>
                    <td>
                        <?php echo e($v['vis_date']); ?>

                    </td>
                    <td>
                        <?php echo e($v['vis_vehicle_work']); ?>

                    </td>
                    <td>
                        <?php echo e($v['notes']); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('report.reportLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>