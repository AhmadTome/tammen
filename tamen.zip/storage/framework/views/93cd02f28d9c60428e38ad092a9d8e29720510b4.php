<?php $__env->startSection('title','دائرة الترخيص'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('report.parts.carInfoHeader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
        <div class="col-xs-4 col-xs-offset-1">
            <?php echo $__env->make('report.parts.fileInfo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>

    <div class="row">
        <div class="col-xs-4 col-xs-offset-8">
            <table class="table table-bordered">
                <tr>
                    <th width='50%' class="gray-back">
                        <?php echo e(_t('car_price',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($car->cost->finalcost); ?>

                    </td>
                </tr>
            </table>
        </div>
    </div>
    <div class="row">
        <table class="table table-bordered">
            <tr>
                <th class="gray-back" colspan="3">
                    <?php echo e(_t('car_price_calculate',$l)); ?>

                </th>
            </tr>
            <tr>
                <th class="gray-back">
                    <?php echo e(_t('repair_calc',$l)); ?>

                </th>
                <th class="gray-back">
                    <?php echo e(_t('body_part_calc',$l)); ?>

                </th>
                <th class="gray-back">
                    <?php echo e(_t('mech_part_calc',$l)); ?>

                </th>
            </tr>
            <tr>
                <td>
                    <?php echo e($car->total_maintenance); ?>

                </td>
                <td>
                    <?php echo e($car->total_body_work); ?>

                </td>
                <td>
                    <?php echo e($car->total_mechanic); ?>

                </td>
            </tr>
        </table>
    </div>
    <br>

    <div class="row">
        <div class="col-xs-8">
            <?php echo $__env->make('report.parts.carGuessNotes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="col-xs-4">
            <?php echo $__env->make('report.parts.attachments', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('report.reportLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>