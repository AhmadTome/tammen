<div>
    <img src="<?php echo e(asset('img/slogo.png')); ?>" class="img-rounded" alt="NotFound" width="50%" height="200" style="margin-top: 38px;">
</div>