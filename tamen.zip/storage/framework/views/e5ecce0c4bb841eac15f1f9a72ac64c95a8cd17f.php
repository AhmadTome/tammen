<?php $__env->startSection('title','أعمال مركبة'); ?>

<?php $__env->startSection('content'); ?>

    <div class="text-center border-1 gray-back">
        <h3>
            <?php echo e(_t('car_work',$l)); ?>

        </h3>
    </div>
    <Br>
    <?php echo $__env->make('report.parts.carInfoHeader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <br>
    <div class="col-xs-8 col-xs-offset-4">
        <table class="table table-bordered">
            <tr>
                <th>
                    <?php echo e(_t('maintain',$l)); ?>

                </th>
                <th>
                    <?php echo e(_t('value_ammount',$l)); ?>

                </th>
                <th>
                    <?php echo e(_t('details',$l)); ?>

                </th>
            </tr>
            <?php $__currentLoopData = $parts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($p->mawo_work_name); ?>

                    </td>
                    <td>
                        <?php echo e($p->mawo_cost); ?>

                    </td>
                    <td>
                        <?php echo e($p->mawo_details); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
    <div class="clearfix"></div>
    <br>
    <div class="col-xs-6 col-xs-offset-6">        
        <table class="table table-bordered">
            <tr>
                <th width="40%" class="gray-back">
                    <?php echo e(_t('total',$l)); ?>

                </th>
                <td>
                </td>
            </tr>
            <tr>
                <th width="40%" class="gray-back">
                    <?php echo e(_t('tax_value',$l)); ?>

                </th>
                <td>
                
                </td>
            </tr>
            <tr>
                <th width="40%" class="gray-back">
                    <?php echo e(_t('money_to_pay',$l)); ?>

                </th>
                <td>
                </td>
            </tr>
        </table>
    </div>

    <div class="clearfix">
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('report.reportLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>