<?php $__env->startSection('title','File Account'); ?>

<?php $__env->startSection('content'); ?>

    <div class="border-2 padding">
    
        <div class="col-xs-6">
            <table class="table table-bordered">
                <tr>
                    <th width="30%">
                        <?php echo e(_t('production_year',$l)); ?>

                    </th>
                    <th>
                        <?php echo e(_t('body_num',$l)); ?>

                    </th>
                </tr>
                <tr>
                    <td>
                        <?php echo e($car['ve_produce_year']); ?>

                    </td>
                    <td>
                        <?php echo e($car['ve_body_num']); ?>

                    </td>
                </tr>
            </table>
        </div>
        <div class="col-xs-3 col-xs-push-3">
            <table class="table table-bordered">
                <tr>
                    <th>
                        <?php echo e(_t('car_num',$l)); ?>

                    </th>
                    <th>
                        <?php echo e(_t('file_num',$l)); ?>

                    </th>
                </tr>
                <tr>
                    <td>
                        <?php echo e($car['ve_num']); ?>

                    </td>
                    <td>
                        <?php echo e($car['file_num']); ?>

                    </td>
                </tr>
            </table>
        </div>
        <div class="clearfix"></div>
    </div>
    <Br>
    <div class="row">
        <div class="col-xs-4 col-xs-push-2">
            <table class="table table-bordered">
                <tr>
                    <th class="gray-back" width="30%">
                        <?php echo e(_t('production_date',$l)); ?>

                    </th>
                    <td colspan="2" width="70%">
                        <?php echo e(date('Y-m-d')); ?>

                    </td>
                </tr>
                <tr>
                    <th class="gray-back" width="30%">
                        <?php echo e(_t('file_num',$l)); ?>

                    </th>
                    <td width="20%">
                        <?php echo e(explode('-',$car['file_num'])[1]); ?>

                    </td>
                    <td width="50%">
                        <?php echo e(explode('-',$car['file_num'])[0]); ?>

                    </td>
                </tr>
                <tr>
                    <th class="gray-back" width="30%">
                        <?php echo e(_t('account_num',$l)); ?>

                    </th>
                    <td width="70%" colspan="2">

                    </td>
                </tr>
            </table>
        </div>
        <div class="col-xs-2"></div>
        <div class="col-xs-4 col-xs-push-2">
            <table class="table table-bordered">
                <tr>
                    <th width="30%" class="gray-back">
                        <?php echo e(_t('for',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($est['to']); ?>

                    </td>
                </tr>
                <tr>
                    <th class="gray-back">
                        <?php echo e(_t('city',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($est['city']); ?>

                    </td>
                </tr>
                <tr>
                    <th class="gray-back">
                        <?php echo e(_t('jawwal',$l)); ?>

                    </th>
                    <td>

                    </td>
                </tr>
            </table>    
        </div>
    </div>
    <p class="text-center">
        <?php echo e(_t('car_check_msg',$l)); ?>

    </p>
    <br>
    <div class="border-1 padding">
        <div class="col-xs-2"></div>
        <div class="col-xs-3">
            <table class="table table-bordered">
                <tr>
                    <th width="30%"> <?php echo e(_t('claim_num',$l)); ?> </th>
                    <td width="70%"> <?php echo e($est['climeNumber']); ?> </td>
                </tr>
            </table>
        </div>
        <div class="col-xs-3">
            <table class="table table-bordered">
                <tr>
                    <th width="30%"> <?php echo e(_t('file_num',$l)); ?> </th>
                    <td width="20%"> <?php echo e(explode('-',$car['file_num'])[1]); ?> </td>
                    <td width="50%"> <?php echo e(explode('-',$car['file_num'])[0]); ?>  </td>
                </tr>
            </table>
        </div>
        <div class="col-xs-4">
            <?php echo e(_t('benif_name_HR',$l)); ?>

        </div>
        <div class="clearfix"></div>
    </div>
    <br>
    <div class="Row">
        <div class="col-xs-6">
            <table class="table table-bordered">
                <tr>
                    <th width="30%">
                        <?php echo e(_t('acc_date',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($est['accidantDate']); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('car_num',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($car['ve_num']); ?>

                    </td>
                </tr>
            </table>
            <br>
            <table class="table table-bordered">
                <tr>
                    <th width="30%">
                        <?php echo e(_t('production_year',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($car['ve_produce_year']); ?>

                    </td>
                </tr>
            </table>
            <br>
        </div>
        <div class="col-xs-6">
            <table class="table table-bordered">
                <tr>
                    <th width="30%">
                        <?php echo e(_t('ins_policy',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($est['Insurance_policy']); ?>

                    </td>
                </tr>
            </table>
            <br>
            <table class="table table-bordered">
                <tr>
                    <th width="30%">
                        <?php echo e(_t('surv_pay',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($est->estimater_cost); ?>

                    </td>
                </tr>
                <tr>
                    <th width='30%'>
                        <?php echo e(_t('travel',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($est['transport']); ?>

                    </td>
                </tr>
                <tr>
                    <th width="30%">
                        <?php echo e(_t('picture',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($est->gelary); ?>

                    </td>
                </tr>
                <tr>
                    <th width="30%">
                        <?php echo e(_t('disk_money',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($est['officeCost']); ?>

                    </td>
                </tr>
                <tr>
                    <th width="30%">
                        <?php echo e(_t('total',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($est->total + $est->estimater_cost); ?>

                    </td>
                </tr>
            </table>
            <br>
        </div>
        <div class="clearfix"></div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('report.reportLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>