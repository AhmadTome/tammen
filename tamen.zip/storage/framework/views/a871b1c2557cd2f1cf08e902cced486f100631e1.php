<?php $__env->startSection('title','تقرير قطع غيار هيكل'); ?>

<?php $__env->startSection('content'); ?>

    <div class="text-center border-2 gray-back">
        <h3>
            <b>
                <?php echo e(_t('body_change',$l)); ?>

            </b>
        </h3>
    </div>
    <br>
    <div>
        <?php echo $__env->make('report.parts.carInfoHeader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <Br>
    <div class="col-xs-8 col-xs-offset-4">
        <table class="table table-bordered">
            <tr>
                <th>
                    <?php echo e(_t('car_parts',$l)); ?>

                </th>
                <th>
                    <?php echo e(_t('part_type',$l)); ?>

                </th>
                <th>
                    <?php echo e(_t('part_price',$l)); ?>

                </th>
                <th>
                    <?php echo e(_t('count',$l)); ?>

                </th>
                <th>
                    <?php echo e(_t('price',$l)); ?>

                </th>
                <th>
                    <?php echo e(_t('part_code',$l)); ?>

                </th>
            </tr>
            <?php $total = 0; ?>
            <?php $__currentLoopData = $parts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($p->bo_part_name); ?>

                    </td>
                    <td>
                        <?php echo e($p->bo_part_type); ?>

                    </td>
                    <td>
                        <?php echo e($p->partPrice); ?>

                    </td>
                    <td>
                        <?php echo e($p->bo_bod_count); ?>

                    </td>
                    <td>
                        <?php $total += $p->bo_bod_count * $p->partPrice; ?>
                        <?php echo e($p->bo_bod_count * $p->partPrice); ?>

                    </td>
                    <td>
                        <?php echo e($p->bo_limit_num); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="visibility:hidden">
                </td>
                <td style="visibility:hidden">
                </td>
                <th class="gray-back" colspan="2">
                    <?php echo e(_t('total',$l)); ?>

                </th>
                <td>
                    <?php echo e($total); ?>

                </td>
            </tr>
            <tr>
                <td style="visibility:hidden">
                </td>
                <td style="visibility:hidden">
                </td>
                <th class="gray-back" colspan="2">
                    <?php echo e(_t('tax_value',$l)); ?>

                </th>
                <td>
                    <?php echo e(tax() * $total); ?>

                </td>
            </tr>
            <tr>
                <td style="visibility:hidden">
                </td>
                <td style="visibility:hidden">
                </td>
                <th class="gray-back" colspan="2">
                    <?php echo e(_t('tax_price',$l)); ?>

                </th>
                <td>
                    <?php echo e($total + calcTax($total)); ?>

                </td>
            </tr>
            <tr>
                <td style="visibility:hidden">
                </td>
                <td style="visibility:hidden">
                </td>
                <th class="gray-back" colspan="2">
                    <?php echo e(_t('consume_ammount',$l)); ?>

                </th>
                <td>

                </td>
            </tr>
            <tr>
                <td style="visibility:hidden">
                </td>
                <td style="visibility:hidden">
                </td>
                <th class="gray-back" colspan="2">
                    <?php echo e(_t('money_to_pay',$l)); ?>

                </th>
                <td>
                </td>
            </tr>
        </table>
    </div>
    <div class="clearfix"></div>
    <br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('report.reportLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>