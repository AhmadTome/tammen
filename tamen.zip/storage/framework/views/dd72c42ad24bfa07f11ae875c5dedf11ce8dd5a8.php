<?php $__env->startSection('title','تقرير قطع غيار هيكل'); ?>

<?php $__env->startSection('content'); ?>

    <div class="text-center border-2 gray-back">
        <h3>
            <b>
                <?php echo e(_t('car_down_table',$l)); ?>

            </b>
        </h3>
    </div>
    <br>
    <div>
        <?php echo $__env->make('report.parts.carInfoHeader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <Br>
    <div class="row">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th class="gray-back">
                        <?php echo e(_t('car_1',$l)); ?>

                    </th>
                    <th class="gray-back">
                        <?php echo e(_t('third_party_stmnt',$l)); ?>

                    </th>
                    <th class="gray-back">
                        <?php echo e(_t('car_2',$l)); ?>

                    </th>
                </tr>
            </thead>
            <tbody>
                <tr style='height:200px;'>
                    <td>
                        <?php echo e($drop->firstCar); ?>

                    </td>
                    <td>
                    
                    </td>
                    <td>
                        <?php echo e($drop->secondCar); ?>

                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    <br>
    <div class="col-xs-3 col-xs-offset-9">
        <table class="table table-bordered">
            <tr>
                <th width="30%">
                    <?php echo e(_t('car_price',$l)); ?>

                </th>
                <td>
                    <?php echo e($drop->finalprice); ?>

                </td>
            </tr>
        </table>
    </div>
    <div class="clearfix"></div>
    <br>
    <div class='col-xs-6 col-xs-offset-6'>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>
                        <?php echo e(_t('part',$l)); ?>

                    </th>
                    <th>
                        <?php echo e(_t('maintenece',$l)); ?>

                    </th>
                    <th>
                        <?php echo e(_t('part_count',$l)); ?>

                    </th>
                    <th>
                        <?php echo e(_t('work_ratio',$l)); ?>

                    </th>
                    <th>
                        <?php echo e(_t('down_ratio')); ?>

                    </th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>
                        <?php echo e($drop->part); ?>

                    </td>
                    <td>
                        <?php echo e($drop->maintinance); ?>

                    </td>
                    <td>
                        <?php echo e($drop->count); ?>

                    </td>
                    <td>
                        <?php echo e($drop->percantige); ?>

                    </td>
                    <td>
                        <?php echo e($drop->percantige); ?>

                    </td>
                </tr>
                <tr>
                    <th colspan="3">
                        <?php echo e(_t('total_down_ratio',$l)); ?>

                    </th>
                    <td>
                    </td>
                </tr>
                <tr>
                    <th colspan="3">
                        <?php echo e(_t("direct_damage",$l)); ?>

                    </th>
                    <td>
                    
                    </td>
                </tr>
                <tr>
                    <th colspan='3'>
                        <?php echo e(_t('total_drop_value',$l)); ?>

                    </th>
                    <td>
                    
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    <div class="clearfix"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('report.reportLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>