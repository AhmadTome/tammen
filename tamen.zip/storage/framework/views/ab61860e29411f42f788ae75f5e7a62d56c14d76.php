<?php $__env->startSection('title','تقرير الرقابة'); ?>

<?php $__env->startSection('content'); ?>
<div class="panel panel-default">
            <div class="panel-heading">
                تقرير الرقابة
            </div>
            <div>
            <form action="/report/monitorReport" method="GET">
                <div class="col-sm-6">
                    <label class="contrl-label">من تاريخ: </label>
                    <input type="date" class="form-control" name='From'>
                </div>
                <div class="col-sm-6">
                    <label class="contrl-label">إلى تاريخ: </label>
                    <input type="date" class="form-control" name='To'>
                </div>
                <div class="clearfix"></div>
                <br>    
                <div class="form-group">
                    <div class="col-md-8 col-md-offset-2">
                        <select name="lang" id="lang" class='form-control'>
                            <option value="AR">اللغة العربية</option>
                            <option value="HR">اللغة العبرية</option>
                        </select>
                    </div>
                    <label class="control-label col-md-2">
                        اللغة
                    </label>
                </div>
                <div class="clearfix"></div>
                <Br>
                <div class="form-group">
                    <div class="col-sm-6 col-sm-offset-3">
                        <button class="btn btn-primary btn-block">
                            معاينة التقرير
                        </button>
                    </div>
                </div>
                <div class="clearfix"></div>
                <br>
                </form>
            </div>
        </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>