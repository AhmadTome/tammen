

<nav class="navbar navbar-default navbar-fixed-top">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand navbar-link" href="#"> </a>
        </div>
        <div class="collapse navbar-collapse" id="navcol-1">
            <ul class="nav navbar-nav navbar-right">
                <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#">التقارير <span class="caret"></span></a>
                    <ul class="dropdown-menu" role="menu">
                        <li><a href="/report/car">تقارير المركبة</a></li>
                        <li><a href="/report/insurance">حساب شركة التأمين</a></li>
                        <li><a href="/report/insurance/benifiter">حساب شركة التامين للمستفيد</a></li>
                        <li><a href="/report/car/parts">تقارير قطع المركبة</a></li>
                        <li><a href="/report/car/bank">تقرير كشف بنك</a></li>
                        <li><a href="/report/monitor">تقرير الرقابة</a></li>
                        <li><a href="/report/images">صور الحادث</a></li>
                    </ul>
                </li>
                <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#">الاستعلامات و التعديلات <span class="caret"></span></a>
                    <ul class="dropdown-menu" role="menu">
                        <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(asset('personalinformationTransaction')); ?>">بيانات شخصية</a></li>
                        <li role="presentation" class="divider"></li>
                        <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(asset('carinfoTransaction')); ?>">بيانات مركبة</a></li>
                        <li role="presentation" class="divider"></li>
                        <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(asset('CarGuessTransaction')); ?>">تخمين مركبة</a></li>
                        <li role="presentation" class="divider"></li>

                        <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(asset('maintinanceTransaction')); ?>"> أعمال صيانة على المركبة</a></li>
                        <li role="presentation" class="divider"></li>
                        <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(asset('mechanicalTransaction')); ?>">قطع غيار ميكانيك</a></li>
                        <li role="presentation" class="divider"></li>
                        <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(asset('BodyTransaction')); ?>">قطع غيار هيكل</a></li>
                        <li role="presentation" class="divider"></li>
                        <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(asset('imageTreansaction')); ?>">صور الحادث</a></li>
                        <li role="presentation" class="divider"></li>

                        <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(asset('dropcarTransaction')); ?>">هبوط مركبة</a></li>
                        <li role="presentation" class="divider"></li>
                        <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(asset('carcostTransaction')); ?>">احتساب سعر مركبة</a></li>
                        <li role="presentation" class="divider"></li>
                        <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(asset('BankTransaction')); ?>">كشف بنك</a></li>
                        <li role="presentation" class="divider"></li>
                        <!--
                        <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(asset('certificationTransaction')); ?>">كشف شهادة</a></li>
                        <li role="presentation" class="divider"></li>
                  -->
                    </ul>
                </li>

                <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#">مدخلات ثابتة <span class="caret"></span></a>
                    <ul class="dropdown-menu" role="menu" style="width:290px; overflow:scroll; height: 500px;">
                        <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(asset('addEstimater')); ?>">ادخال مخمن</a></li>
                        <li role="presentation" class="divider"></li>
                        <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(asset('addDamage')); ?>">ادخال ضرر</a></li>
                        <li role="presentation" class="divider"></li>
                        <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(asset('addCertification')); ?>">ادخال شهادة</a></li>
                        <li role="presentation" class="divider"></li>
                        <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(asset('addMechParts')); ?>">ادخال أجزاء ميكانيكية</a></li>
                        <li role="presentation" class="divider"></li>
                        <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(asset('addBodyParts')); ?>">ادخال أجزاء هيكل</a></li>
                        <li role="presentation" class="divider"></li>
                        <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(asset('addMaintinance')); ?>">ادخال صيانة</a></li>
                        <li role="presentation" class="divider"></li>
                        <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(asset('addInsuranceCompany')); ?>">ادخال شركة تأمين</a></li>
                        <li role="presentation" class="divider"></li>
                        <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(asset('garage')); ?>">ادخال كراج</a></li>
                        <li role="presentation" class="divider"></li>
                        <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(asset('addTextStructure')); ?>">ادخال نص تركيب</a></li>
                        <li role="presentation" class="divider"></li>
                        <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(asset('crossOff')); ?>">ادخال شطب</a></li>
                        <li role="presentation" class="divider"></li>
                        <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(asset('addEstimatevalue')); ?>">ادخال قيمة تخمين</a></li>
                        <li role="presentation" class="divider"></li>
                        <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(asset('addAccedentSide')); ?>">ادخال طرف حادث</a></li>
                        <li role="presentation" class="divider"></li>
                        <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(asset('dropStatment')); ?>">ادخال بيان هبوط قيمة</a></li>
                        <li role="presentation" class="divider"></li>
                        <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(asset('addCity')); ?>">ادخال مدينة</a></li>

                    </ul>
                </li>
                <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#">المدخلات الرئيسية <span class="caret"></span></a>
                    <ul class="dropdown-menu" role="menu">
                        <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(asset('addpersonalInformation')); ?>">ادخال بيانات شخصية</a></li>
                        <li role="presentation" class="divider"></li>
                        <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(asset('addCarInformation')); ?>">ادخال بيانات مركبة</a></li>
                        <li role="presentation" class="divider"></li>

                        <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(asset('carGuess')); ?>">ادخال تخمين مركبة</a></li>
                        <li role="presentation" class="divider"></li>

                        <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(asset('addcarTransaction')); ?>"> ادخال العمليات على المركبة</a></li>
                        <li role="presentation" class="divider"></li>
                        <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(asset('dropvalue')); ?>"> ادخال هبوط المركبة</a></li>
                        <li role="presentation" class="divider"></li>
                        <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(asset('sendMessage')); ?>">ادخال مراسلة</a></li>
                        <li role="presentation" class="divider"></li>
                        <li role="presentation"><a role="menuitem" tabindex="-1" href=<?php echo e(asset('carCost')); ?>>احتساب سعر المركبة</a></li>
                        <li role="presentation" class="divider"></li>
                        <li role="presentation"><a role="menuitem" tabindex="-1" href=<?php echo e(asset('BankDisclosure')); ?>>ادخال كشف بنك</a></li>

                        <!--
                        <li role="presentation" class="divider"></li>
                        <li role="presentation"><a role="menuitem" tabindex="-1" href=<?php echo e(asset('CertificationInput')); ?>>ادخال كشف شهادة</a></li>
-->

                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>