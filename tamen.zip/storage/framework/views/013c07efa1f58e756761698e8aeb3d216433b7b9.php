<?php $__env->startSection('titile','تقرير أضرار أولي'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <h4 class="gray-back text-center padding">
            <b>
                <?php echo e(_t('init_damage_report',$l)); ?>

            </b>
        </h4>
    </div>
    <br>

    <div class="row">
        <div class="col-xs-6">
            <table class="table table-bordered">
                <tr>
                    <th width="30%">
                        <?php echo e(_t('file_num',$l)); ?>

                    </th>
                    <td width="20%">
                        <?php echo e(explode('-',$car['file_num'])[1]); ?>

                    </td>
                    <td>
                        <?php echo e(explode('-',$car['file_num'])[0]); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('car_num',$l)); ?>

                    </th>
                    <td colspan="2">
                        <?php echo e($car['ve_num']); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('car_use',$l)); ?>

                    </th>
                    <td colspan="2">
                        <?php echo e($car['ve_used']); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('production_year',$l)); ?>

                    </th>
                    <td colspan="2">
                        <?php echo e($car['ve_produce_year']); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('meter',$l)); ?>

                    </th>
                    <td colspan="2">
                        <?php echo e($car['ve_speedometer']); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('body_num',$l)); ?>

                    </th>
                    <td colspan="2">
                        <?php echo e($car['ve_body_num']); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('visit_pay',$l)); ?>

                    </th>
                    <td colspan="2">
                        <?php echo e($est['visitCost']); ?>

                    </td>
                </tr>
            </table>
        </div>
        <div class="col-xs-6">
            <table class="table table-bordered">
                <tr>
                    <th width="30%">
                        <?php echo e(_t('acc_date',$l)); ?>

                    </th>
                    <td colspan="2">
                        <?php echo e($est['accidantDate']); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('exam_date',$l)); ?>

                    </th>
                    <td colspan="2">
                        <?php echo e($est['checkDate']); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('garage_name',$l)); ?>

                    </th>
                    <td colspan="2">
                        <?php echo e($est['Garage']); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('name',$l)); ?>

                    </th>
                    <td colspan="2">
                        <?php echo e($est['persone_name']); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('ins_name',$l)); ?>

                    </th>
                    <td colspan="2">
                        <?php echo e($est['person_insurances']); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('phone',$l)); ?>

                    </th>
                    <td width="35%">
                    
                    </td>
                    <td width="35%">
                    
                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(_t('ins_company',$l)); ?>

                    </th>
                    <td colspan="2">
                        <?php echo e($est['insurance_company']); ?>

                    </td>
                </tr>
            </table>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-xs-4">
            <table class="table table-bordered table-0">
                <tr>
                    <th class="gray-back" colspan="2">
                        <?php echo e(_t('additions',$l)); ?>

                    </th>
                </tr>
                <?php for($i = 1; $i <= 12; $i++): ?>
                    <tr>
                        <th width="20%"> 
                            <?php echo e($i); ?>

                        </th>
                        <td>
                        </td>
                    </tr>
                <?php endfor; ?>
            </table>
        </div>
        <div class="col-xs-8">
            <table class="table table-bordered" >
                <tr height="250px">
                    <td colspan="2" width="40%"></td>
                    <td rowspan="5" width="30%"></td>
                    <td rowspan="5" width="30%"></td>
                </tr>
                <tr>
                    <th width="30%">
                        <?php echo e(_t('repair_calc',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($car->total_maintenance_work); ?>

                    </td>
                </tr>
                <tr>
                    <th width="30%">
                        <?php echo e(_t('body_part_calc',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($car->total_body_work); ?>

                    </td>
                </tr>
                <tr>
                    <th width="30%">
                        <?php echo e(_t('mech_part_calc',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($car->total_mechanic); ?>

                    </td>
                </tr>
                <tr>
                    <th width="30%">
                        <?php echo e(_t('car_price',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($car->cost->finalcost); ?>

                    </td>
                </tr>
            </table>
        </div>
    </div>
    <br>
    <div class='row'>
        <div class="col-xs-10 col-xs-offset-1">
            <table class="table table-bordered">
                <tr>
                    <th width="50%" class="gray-back">
                        <?php echo e(_t('damage_desc',$l)); ?>

                    </th>
                    <th class="gray-back">
                        <?php echo e(_t('recomendations',$l)); ?>

                    </th>
                </tr>
                <tr height="80px">
                    <td></td>
                    <td></td>
                </tr>
            </table>
        </div>
    </div>
    <div class='row'>
        <div class="col-xs-4">
            <p>
                <?php echo e(_t('garage_sig',$l)); ?>: ..................................
            </p>
            <p>
                <?php echo e(_t('garage_phone',$l)); ?>: ................................
            </p>
        </div>
        <div class="col-xs-8">
            1- <?php echo e(_t('init_damage_msg_1',$l)); ?>

            <br>
            2- <?php echo e(_t('init_damage_msg_2',$l)); ?>

            <br>
            3- <?php echo e(_t('init_damage_msg_3',$l)); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('report.reportLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>