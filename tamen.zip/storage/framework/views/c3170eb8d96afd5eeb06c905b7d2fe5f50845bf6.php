<?php $__env->startSection('title','كشف حساب شركة التامين'); ?>

<?php $__env->startSection('content'); ?>

    <div class="text-center">
        <h3>
            <u>
                <b>
                    <?php echo e(_t('ins_company_acc_title',$l)); ?>

                </b>
            </u>
        </h3>
    </div>
    <br>
    <div class="row">
        <div class="col-xs-4 col-xs-offset-4">
            <table class="table table-bordered">
                <tr>
                    <th width="30%">
                        <?php echo e(_t('ins_company',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($company->ins_name); ?>

                    </td>
                </tr>
            </table>
        </div>
        <div class="col-xs-4">
            <table class="table table-bordered">
                <tr>
                    <th width="50%">
                        <?php echo e(_t('ins_company_num',$l)); ?>

                    </th>
                    <td>
                        <?php echo e($company->ins_num); ?>

                    </td>
                </tr>
            </table>
        </div>
    </div>
    <hr>
    <div class="row">
        <table class="table table-bordered">
            <tr>
                <th>
                    <?php echo e(_t('car_num',$l)); ?>

                </th>
                <th>
                    <?php echo e(_t('file_num',$l)); ?>

                </th>
                <th>
                    <?php echo e(_t('claim_num',$l)); ?>

                </th>
                <th>
                    <?php echo e(_t('det',$l)); ?>

                </th>
                <th>
                    <?php echo e(_t('det',$l)); ?>

                </th>
                <th>
                    <?php echo e(_t('init_damage_detect',$l)); ?>

                </th>
                <th>
                    <?php echo e(_t('travel',$l)); ?>

                </th>
                <th>
                    <?php echo e(_t('picture',$l)); ?>

                </th>
                <th>
                    <?php echo e(_t('disk_money',$l)); ?>

                </th>
                <th>
                    <?php echo e(_t('surv_pay',$l)); ?>

                </th>
                <th>
                    <?php echo e(_t('total',$l)); ?>

                </th>
                <th>
                    <?php echo e(_t('reg_date',$l)); ?>

                </th>
            </tr>
            <?php 
                $totalTransport = 0;
                $totalGelary = 0;
                $totalOfficeCost = 0;
                $totalEstimaterCost = 0;
                $total = 0;
            ?>
            <?php $__currentLoopData = $ests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($e->carInfo->ve_num); ?>

                    </td>
                    <td>
                        <?php echo e($e->fileNumber); ?>

                    </td>
                    <td>
                        <?php echo e($e->climeNumber); ?>

                    </td>
                    <td>
                        
                    </td>
                    <td>
                    
                    </td>
                    <td>

                    </td>
                    <td>
                        <?php echo e($e->transport); ?>

                    </td>
                    <td>
                        <?php echo e($e->gelary); ?>

                    </td>
                    <td>
                        <?php echo e($e->officeCost); ?>

                    </td>
                    <td>
                        <?php echo e($e->estimater_cost); ?>

                    </td>
                    <td>
                        <?php echo e($e->total); ?>

                    </td>
                    <td>
                        <?php echo e($e->registerDate); ?>

                    </td>
                </tr>
                <?php
                    $totalTransport += $e->transport;
                    $totalGelary += $e->gelary;
                    $totalOfficeCost += $e->officeCost;
                    $totalEstimaterCost += $e->estimater_cost;
                    $total += $e->total;
                ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="visibility:hidden;">
                </td>
                <td style="visibility:hidden;">
                </td>
                <td style="visibility:hidden;">
                </td>
                <td style="visibility:hidden;">
                </td>
                <td style="visibility:hidden;">
                </td>
                <td>
                    <?php echo e(_t('total_sum',$l)); ?>

                </td>
                <td>
                    <?php echo e($totalTransport); ?>

                </td>
                <td>
                    <?php echo e($totalGelary); ?>

                </td>
                <td>
                    <?php echo e($totalOfficeCost); ?>

                </td>
                <td>
                    <?php echo e($totalEstimaterCost); ?>

                </td>
                <td>
                    <?php echo e($total); ?>

                </td>
            </tr>
        </table>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('report.reportLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>