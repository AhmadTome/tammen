
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>ادخال كراج</title>
    <link rel="icon" type="image/ico" href="<?php echo e(asset (img/photo2.png)); ?>">
    <link href="<?php echo e(asset(bootsrap.com/bootstrap.min.css)); ?>" rel="stylesheet">

    <!-- <script src="/JS/SAdminJS/AddNewSAdmin.js"></script>
       <script src="/JS/SAdminJS/AddNewAdmin.js"></script> -->
</head>
<body  >
<div class="container-fluid">
    <!-- Background pic -->
    <div class="BackImageSuperAd" ></div>
    <!-- End of Background pic -->


    <div class="row ">
        <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12 text-right" >
            <a href="http://localhost/finalProject/index.php" class="btn btn-danger exit" title="Exit"><b>Exit</b></a>
        </div>
    </div>

    <div class="row headrDiv">
        <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12 " >


        </div>
    </div>

    <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12 " >

    </div>

    <!--Body-->



    <div class="BodyDiv col-lg-12 col-md-12 col-xs-12 col-sm-12 " >
        <div class="panel panel-default">
            <div class="panel-heading text-center PanelHeadingCss">ادخال كراج</div>
            <div class="panel-body PanelBodyCss">

                <div class="container " style="max-width: 1000px ;margin-bottom: -15px">
                    <form class="form-horizontal" >

                        <div class="form-group">
                            <div class="col-sm-2"></div>
                            <div class="col-sm-9">
                                <input type="name" class="form-control PanelBodyCssInput" id="garNum" placeholder="ادخل رقم الكراج">
                            </div>
                            <label class="control-label col-sm-1" for="garNum">: الرقم</label>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-2"></div>
                            <div class="col-sm-9">
                                <input type="address" class="form-control PanelBodyCssInput" id="garName" placeholder="ادخل الاسم">
                            </div>
                            <label class="control-label col-sm-1" for="garName">: الاسم</label>
                        </div>


                    </form>
                </div>


            </div>
        </div>



    </div>

    <!--footer-->

    <!--/footer-->



</div>

</body>
</html>