<?php $__env->startSection('title','شهادة مركبة'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('report.parts.carInfoHeader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <br>
    <h3 class='text-center'>
        <b>
            <?php echo e(_t('degree',$l)); ?>

        </b>
    </h3>
    <Br>
    <div>
        <?php echo e($cer->cert); ?>

    </div>
    <br>
    <br>
    <div>
        <div class="pull-left">
            <i>
                <u>
                    <?php echo e(_t("sig_stamp",$l)); ?>

                </u>
            </i>
        </div>
    </div>
    <div class='clearfix'>

    </div>
    <br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('report.reportLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>