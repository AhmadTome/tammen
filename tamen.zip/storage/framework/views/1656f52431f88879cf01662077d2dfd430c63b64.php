<html>
<head>
<meta charset="utf-8">
    <title>first page</title>

</head>
<body>
<?php echo $__env->yieldContent('content'); ?>
</body>

</html>
