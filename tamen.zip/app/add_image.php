<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class add_image extends Model
{
    //
}
