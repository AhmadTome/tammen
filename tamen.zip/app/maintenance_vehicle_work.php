<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class maintenance_vehicle_work extends Model
{
    protected $table ="maintenance_vehicle_work";
}
