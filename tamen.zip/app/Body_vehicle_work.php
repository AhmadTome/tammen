<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Body_vehicle_work extends Model
{
    //
}
