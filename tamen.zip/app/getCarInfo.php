<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class getCarInfo extends Model
{
    protected $table ="enter_car_infos";
}
