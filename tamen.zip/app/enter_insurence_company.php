<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class enter_insurence_company extends Model
{
    protected $primaryKey = 'ins_num';
}
