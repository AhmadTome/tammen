<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class enter_structer_text extends Model
{
    //
}
