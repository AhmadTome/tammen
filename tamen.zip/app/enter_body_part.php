<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class enter_body_part extends Model
{
    //
}
