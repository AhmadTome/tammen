<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CarVisit extends Model
{
    protected $table = 'enter_vehicle_visit';
    public $incrementing = false;
}
