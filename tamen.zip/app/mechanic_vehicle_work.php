<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class mechanic_vehicle_work extends Model
{
    //
}
