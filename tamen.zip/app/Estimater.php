<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Estimater extends Model
{
    //
}
