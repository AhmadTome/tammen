<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class enter_maintinance extends Model
{
    //
}
