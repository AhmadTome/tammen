<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class enter_garage extends Model
{
    //
}
