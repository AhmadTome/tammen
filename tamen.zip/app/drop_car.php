<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class drop_car extends Model
{
    //
}
