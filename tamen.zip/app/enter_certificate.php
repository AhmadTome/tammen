<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class enter_certificate extends Model
{
    //
}
