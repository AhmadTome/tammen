<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class enter_mechanic_part extends Model
{
    //
}
